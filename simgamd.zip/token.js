module.exports = {
  BOT_TOKEN: '8936698172:AAGwHe5y26RhwbsHYONNF_HGppHBWsYpsuA',  
};
