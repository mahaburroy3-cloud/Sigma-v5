const fs = require("fs");
const path = require("path");
try { require("dotenv").config(); } catch { /* dotenv optional */ }

// ---- Where settings are read from (first real value wins) ----
//   1. panel environment variables   2. settings.json   3. .env   4. .env.example   5. settings.txt
// If someone pastes the token into the "wrong" one of these files, it still works.
const SOURCES = ["settings.json", ".env", ".env.example", "settings.txt"];
const PLACEHOLDER = /paste-your|your[_-]?token|^\s*$/i;
const TOKEN_RE = /\b\d{6,12}:[A-Za-z0-9_-]{30,}\b/;

function readSource(name) {
    let text = "";
    try { text = fs.readFileSync(path.join(__dirname, name), "utf8"); } catch { return null; }
    let obj = {};
    try { obj = JSON.parse(text); }
    catch {
        for (const line of text.split(/\r?\n/)) {
            const m = line.match(/^\s*([A-Z_]+)\s*[=:]\s*(.*?)\s*$/);
            if (m && !line.trim().startsWith("#")) obj[m[1]] = m[2].replace(/^["']|["'],?$/g, "").replace(/,$/, "");
        }
    }
    return { name, text, obj };
}
const loaded = SOURCES.map(readSource).filter(Boolean);

let tokenSource = "";
const get = (k) => {
    const env = String(process.env[k] || "").trim();
    if (env && !PLACEHOLDER.test(env)) { if (k === "BOT_TOKEN") tokenSource = "server environment variable"; return env; }
    for (const src of loaded) {
        const v = String(src.obj[k] ?? "").trim();
        if (v && !PLACEHOLDER.test(v)) { if (k === "BOT_TOKEN") tokenSource = src.name; return v; }
    }
    if (k === "BOT_TOKEN") {            // last resort: a token pasted anywhere in those files
        for (const src of loaded) {
            const m = src.text.match(TOKEN_RE);
            if (m) { tokenSource = src.name + " (found by scanning)"; return m[0]; }
        }
    }
    return "";
};
const digits = (s) => String(s || "").replace(/\D/g, "");
const list = (s) => String(s || "").split(",").map((x) => x.trim()).filter(Boolean);

module.exports = {
    botName: "SIGMA 5",
    footer: "SIGMA 5 • Made with love",
    tgToken: get("BOT_TOKEN"),
    tokenSource,
    tgApi: (get("TG_API_URL") || "https://api.telegram.org").replace(/\/$/, ""),
    tgAdmins: list(get("TG_ADMIN_IDS")),
    ownerNumbers: list(get("OWNER_NUMBERS")).map(digits),
    maxSessions: get("MAX_SESSIONS"),          // number, or "auto" (decided from available memory)
    maxPerUser: parseInt(get("MAX_PER_USER") || "6", 10),
    memGuardPct: 0.85,
    // Telegram users must join these once before they can use the bot (checked with getChatMember).
    requiredChats: [
        { title: "Channel 1", username: "mahabur99xx9", url: "https://t.me/mahabur99xx9" },
        { title: "Channel 2", username: "botviproy99x", url: "https://t.me/botviproy99x" },
        { title: "Group", username: "mahabuthzj", url: "https://t.me/mahabuthzj" }
    ],
    groqKey: get("GROQ_API_KEY"),
    timezone: get("TZ_NAME") || "Asia/Kolkata",
    msgDeleteMin: Math.min(60, Math.max(1, parseInt(get("MSG_DELETE_MINUTES") || "10", 10) || 10)),   // Telegram pairing messages are deleted after this many minutes
    menuLink: (get("MENU_LINK") || "").trim(),   // your Telegram personal link, shown under the menu
    terminalNumber: digits(get("WA_PHONE_NUMBER")),
    defaultPrefix: ".",
    sessionsDir: path.join(__dirname, "sessions"),
    dataDir: path.join(__dirname, "data"),
    mediaDir: path.join(__dirname, "media"),
    pairTimeoutMs: 3 * 60 * 1000,

    antispam: { windowMs: 10_000, maxMessages: 6, warnLimit: 3 },
    suspiciousDomainPatterns: [
        /bit\.ly/i, /tinyurl\.com/i, /free-?gift/i, /whatsapp-?gift/i,
        /wa\.me\/\d+\?text=.*(free|gift|prize|winner)/i,
        /\.xyz\/.*(free|gift|claim)/i, /apk[-_]?download[-_]?free/i
    ]
};
