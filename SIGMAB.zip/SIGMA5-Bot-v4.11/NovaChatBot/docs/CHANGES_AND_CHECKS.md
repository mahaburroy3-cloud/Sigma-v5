# SIGMA 5 — what was checked, what was fixed, known limits

## Fixed in this round
1. **Logout detection.** The bot now reads the WhatsApp status code straight from the disconnect error. A network drop (428) keeps the link and reconnects. A WhatsApp logout (401) removes the saved session and tells you on Telegram. After that the same number can be paired again with a new code.
2. **One-tap copy.** The pairing message has a "📋 Copy code" button, and the code is also tap-to-copy.
3. **Group auto-react.** `.autoreact on|off` puts an emoji on each member's chat message. Commands and your own messages are skipped.
4. **Owner status reaction.** `.statusreact on|off` reacts to contacts' statuses with an emoji.
5. **Welcome cards.** Each new member gets their own card with their profile picture, number and name. Names in any language are kept (emoji removed). Up to 20 people per add event, paced.
6. **Menu link.** `MENU_LINK` in `settings.json` shows under `.menu`.
7. **Cleanup.** Removed a duplicated mode check in the message handler.

## Checked and working (mock tests)
- All 156 WhatsApp commands run without errors (124 fully, 26 need internet on the host, 6 need a reply or photo). See COMMAND_REPORT.md.
- Antilink: link removal, kick, warn after 3, all-links mode, admins exempt, bot-not-admin hint.
- Link device: one pairing code per attempt; connection persists through network drops; re-pair after logout works.
- Telegram: join-gate checks, number and code messages cleaned up on connect.

## Known limits (cannot be tested here)
- Not run against a live WhatsApp or Telegram account. Test the first real pairing, join and reaction on your host.
- If the host restarts or sleeps, the bot reconnects saved sessions on start. This needs a host with persistent storage.
- If WhatsApp never sends a logout (for example the phone was off for a long time), the bot can still show the number as linked. Use /unpair, then link again.
- Member names come only from messages the member posted since the bot linked. Otherwise the card shows "Member".
- Telegram may refuse to delete a user's own message in some cases; the bot's own messages are always deleted.
- Heavy use can get WhatsApp numbers restricted. Capacity depends on RAM (see README).
- View-once media is not saved. `.save` works for normal media.

## v4.6
- Telegram pairing messages (your number, the code, the connected/failed notes) are deleted automatically after `MSG_DELETE_MINUTES` (default 10). Set it in settings.json.
- Menu: the menu is the photo with the command list, as before. The personal Telegram link (`MENU_LINK`) sits right under the header.

## v4.7
- `.menu` sends two WhatsApp messages: a photo with a short header and your Telegram link, then the full command list (all 157 commands) as text. The long single caption could be cut off on some phones.
- Telegram start guide now says the number/code messages are deleted after MSG_DELETE_MINUTES.
- docs/COMMANDS_DETAILED.md lists every command with what it does and its test status.

## v4.8
- Telegram `/start` sends only the banner photo with the buttons (Link Device, My Numbers, Unlink). The text guide is removed from the chat.
- In private chats, your messages and the bot's replies are deleted automatically after MSG_DELETE_MINUTES (default 10).
- Checked: pairing and re-pairing, logout cleanup, all command tests, auto-react, menu delivery, reply speed.
- Not run through a Telegram simulator: the `/start` photo path and the private-chat auto-delete. Check these on your host.

## v4.9
- Telegram `/start` has two buttons: 🔗 Number Pairing (send your number, get the 8-character code) and ❌ Unpair (unlinks only your own number from WhatsApp).
- Menu photos are padded to a square, so WhatsApp no longer crops them. The command list is sent as the second message and opens in full, or after tapping "Read more" if WhatsApp collapses it.
- Checked: unpairing one friend leaves other friends connected; a friend can pair again afterwards.
- Capacity: each linked number uses about 55 MB of RAM. A 300 MB host runs about 3–4 numbers. Many friends need a bigger server (see README).

## v4.10
- Telegram banner and WhatsApp menu photos replaced with the new SIGMA 5 wolf image (telegram.jpg, menu.jpg, menu2.jpg). Both uploaded images were byte-identical, so the same photo is used in both places.
- The link stays up. It only ends when you unlink on WhatsApp (logout) or ban the account, or when you tap Unpair on Telegram. Other drops reconnect automatically with the saved link. Tested: several drops in a row, then a logout.
- Checked: pairing, re-pairing, unpair of one friend while others stay connected, auto-react, menu delivery, command tests, pairing messages deleted after the set time.
- Limits: the link survives restarts only if the host keeps the sessions folder. Capacity depends on RAM (see README).

## v4.11
- Each Telegram user can link up to 6 WhatsApp numbers by default (MAX_PER_USER in settings.json; was 1).
- Capacity still applies: each number uses about 55 MB of RAM, so the host's memory decides how many numbers run in total.
