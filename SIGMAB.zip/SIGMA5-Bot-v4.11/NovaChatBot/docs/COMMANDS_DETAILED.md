# SIGMA 5 — every WhatsApp command, what it does, and test status

Total commands: 157. Type the command with the dot in front, e.g. `.dice`.

**Status meanings:** WORKS = runs and replies in the test. NEEDS INTERNET = works on your host where it can reach the service (the test has no internet). WORKS (needs a reply/photo) = needs you to reply to a message or photo first.

## AI (2)

| Command | What it does | Test status |
|---|---|---|
| `.ai` | Ask the AI a question and get an answer (free AI service) | NEEDS INTERNET (works on your host) |
| `.groq` | Ask a question using Groq AI (needs GROQ_API_KEY in settings.json) | NEEDS API KEY (add GROQ_API_KEY) |

## ANIME (13)

| Command | What it does | Test status |
|---|---|---|
| `.anime` | Search an anime title and show info | NEEDS INTERNET (works on your host) |
| `.character` | Look up an anime character | NEEDS INTERNET (works on your host) |
| `.cry` | Send an anime crying GIF/picture | NEEDS INTERNET (works on your host) |
| `.dance` | Send an anime dance GIF/picture | NEEDS INTERNET (works on your host) |
| `.hug` | Send an anime hug GIF/picture to a chat | NEEDS INTERNET (works on your host) |
| `.manga` | Search a manga title and show info | NEEDS INTERNET (works on your host) |
| `.megumin` | Send a random anime picture (megumin) | NEEDS INTERNET (works on your host) |
| `.neko` | Send a random anime picture (neko) | NEEDS INTERNET (works on your host) |
| `.pat` | Send an anime pat GIF/picture | NEEDS INTERNET (works on your host) |
| `.shinobu` | Send a random anime picture (shinobu) | NEEDS INTERNET (works on your host) |
| `.smile` | Send an anime smile GIF/picture | NEEDS INTERNET (works on your host) |
| `.waifu` | Send a random anime picture | NEEDS INTERNET (works on your host) |
| `.wave` | Send an anime wave GIF/picture | NEEDS INTERNET (works on your host) |

## CONVERTER (10)

| Command | What it does | Test status |
|---|---|---|
| `.c2f` | Celsius to Fahrenheit (usage: .c2f 100) | WORKS |
| `.cm2in` | Centimetres to inches | WORKS |
| `.currency` | Convert money between currencies (usage: .currency 10 usd bdt), live rates | WORKS |
| `.f2c` | Fahrenheit to Celsius (usage: .f2c 212) | WORKS |
| `.in2cm` | Inches to centimetres | WORKS |
| `.kg2lb` | Kilograms to pounds | WORKS |
| `.km2mi` | Kilometres to miles | WORKS |
| `.lb2kg` | Pounds to kilograms | WORKS |
| `.mi2km` | Miles to kilometres | WORKS |
| `.toimg` | Turn a replied sticker into a picture | WORKS (needs a reply/photo to act on) |

## DEVOTION (3)

| Command | What it does | Test status |
|---|---|---|
| `.bible` | Show a Bible verse (usage: .bible john 3:16) | NEEDS INTERNET (works on your host) |
| `.gita` | Show a Bhagavad Gita verse (usage: .gita 2:47) | NEEDS INTERNET (works on your host) |
| `.quran` | Show a Quran verse (usage: .quran 2:255) | NEEDS INTERNET (works on your host) |

## FUN (11)

| Command | What it does | Test status |
|---|---|---|
| `.8ball` | Magic 8-ball answer to your question | WORKS |
| `.compliment` | Send a random compliment | WORKS |
| `.dare` | Send a random dare | WORKS |
| `.fact` | Send a random fun fact | WORKS |
| `.joke` | Send a random joke | WORKS |
| `.motivate` | Send a motivational line | WORKS |
| `.quote` | Send a random quote | WORKS |
| `.riddle` | Send a riddle with its answer | WORKS |
| `.trivia` | Send a trivia question with its answer | WORKS |
| `.truth` | Send a random truth question | WORKS |
| `.wyr` | Would-you-rather question | WORKS |

## GAMES (8)

| Command | What it does | Test status |
|---|---|---|
| `.choose` | Pick one from a list (usage: .choose tea, coffee, juice) | WORKS |
| `.coinflip` | Flip a coin: heads or tails | WORKS |
| `.dice` | Roll a six-sided dice | WORKS |
| `.guess` | Guess a number 1-10 (usage: .guess 5) | WORKS |
| `.number` | Random number up to a limit (usage: .number 50) | WORKS |
| `.rps` | Rock, paper, scissors against the bot (usage: .rps rock) | WORKS |
| `.ship` | Compatibility score between two names (usage: .ship name1 & name2) | WORKS |
| `.slots` | Slot machine game | WORKS |

## GENERAL (8)

| Command | What it does | Test status |
|---|---|---|
| `.alive` | Show the bot is online, with the photo | WORKS |
| `.botid` | Show the bot's WhatsApp id | WORKS |
| `.info` | Show bot info (name, version, owner) | WORKS |
| `.menu` | Show the photo and the full command list | WORKS |
| `.owner` | Show the owner contact | WORKS |
| `.ping` | Check reply speed | WORKS |
| `.runtime` | Show how long the bot has been running | WORKS |
| `.time` | Show the current time (bot timezone) | WORKS |

## GROUP (27)

| Command | What it does | Test status |
|---|---|---|
| `.add` | Add a member to this group (admin) | WORKS |
| `.admin` | Make a member admin (admin) | WORKS |
| `.approve` | Approve join requests (admin) | WORKS |
| `.autoreact` | Put an emoji on every member's chat message in this group (admin) | WORKS |
| `.close` | Only admins can send messages (admin) | WORKS |
| `.demote` | Remove admin rights from a member (admin) | WORKS |
| `.desc` | Change the group description (admin) | WORKS |
| `.goodbye` | Turn goodbye cards on|off (admin) | WORKS |
| `.groupinfo` | Show group details: name, members, admins | WORKS |
| `.grouplink` | Show the group invite link | WORKS |
| `.hidetag` | Mention everyone silently with your text (admin) | WORKS |
| `.invite` | Send an invite to a number (admin) | WORKS |
| `.kick` | Remove a member (admin) | WORKS |
| `.lang` | Set welcome/goodbye language: .lang en or .lang bn (admin) | WORKS |
| `.leave` | Make the bot leave the group (owner) | WORKS |
| `.lock` | Only admins can change group info (admin) | WORKS |
| `.open` | Everyone can send messages (admin) | WORKS |
| `.poll` | Create a poll (usage: .poll Question | option1 | option2) | WORKS |
| `.promote` | Make a member admin (admin) | WORKS |
| `.reject` | Reject join requests (admin) | WORKS |
| `.requests` | List join requests (admin) | WORKS |
| `.resetlink` | Reset the group invite link (admin) | WORKS |
| `.setgpp` | Change the group photo (reply to an image, admin) | WORKS (needs a reply/photo to act on) |
| `.subject` | Change the group name (admin) | WORKS |
| `.tagall` | Mention every member with your text (admin) | WORKS |
| `.unlock` | Members can change group info (admin) | WORKS |
| `.welcome` | Turn welcome cards on|off (admin) | WORKS |

## INFO (5)

| Command | What it does | Test status |
|---|---|---|
| `.checkid` | Check a group or chat id | WORKS |
| `.getpp` | Get a contact's profile photo | WORKS |
| `.jid` | Show the chat id of this chat | WORKS |
| `.lyrics` | Search song lyrics | NEEDS INTERNET (works on your host) |
| `.weather` | Show the weather for a city (usage: .weather Kolkata) | NEEDS INTERNET (works on your host) |

## MEDIA (2)

| Command | What it does | Test status |
|---|---|---|
| `.save` | Save normal (not view-once) media to your own chat (reply to a photo, video, audio or file) | WORKS (needs a reply/photo to act on) |
| `.sticker` | Turn a replied image or short video into a sticker | WORKS (needs a reply/photo to act on) |

## MICS (1)

| Command | What it does | Test status |
|---|---|---|
| `.trt` | Translate text (usage: .trt bn hello) | NEEDS INTERNET (works on your host) |

## OWNER (20)

| Command | What it does | Test status |
|---|---|---|
| `.anticall` | Auto-reject incoming calls on|off (owner) | WORKS |
| `.autoread` | Auto-read messages on|off (owner) | WORKS |
| `.autorecord` | Show recording indicator on|off (owner) | WORKS |
| `.autostatus` | Auto-view contacts' statuses on|off (owner) | WORKS |
| `.autotyping` | Show typing indicator on|off (owner) | WORKS |
| `.block` | Block a number (owner) | WORKS |
| `.blocklist` | Show blocked numbers (owner) | WORKS |
| `.broadcast` | Send a message to all chats (owner) | WORKS |
| `.delete` | Delete a replied message (owner) | WORKS (needs a reply/photo to act on) |
| `.join` | Join a group by invite link (owner) | WORKS |
| `.listgc` | List groups the bot is in (owner) | WORKS |
| `.mode` | Set public or self mode (owner) | WORKS |
| `.removepp` | Remove the bot's profile photo (owner) | WORKS |
| `.restart` | Restart the bot session (owner) | WORKS |
| `.setbio` | Change the bot's bio (owner) | WORKS |
| `.setname` | Change the bot's name (owner) | WORKS |
| `.setpp` | Change the bot's profile photo (owner) | WORKS (needs a reply/photo to act on) |
| `.setprefix` | Change the command prefix (owner) | WORKS |
| `.statusreact` | React to contacts' statuses with an emoji on|off (owner) | WORKS |
| `.unblock` | Unblock a number (owner) | WORKS |

## PROTECTION (4)

| Command | What it does | Test status |
|---|---|---|
| `.antilink` | Remove senders who post links: on (kick), warn (3 warnings), all (any link), off | WORKS |
| `.antispam` | Stop spam and fast flooding on|off | WORKS |
| `.resetwarn` | Reset a member's warnings | WORKS |
| `.warnings` | Show warnings given to members | WORKS |

## SEARCH (4)

| Command | What it does | Test status |
|---|---|---|
| `.define` | Dictionary meaning of a word | NEEDS INTERNET (works on your host) |
| `.github` | Show a GitHub user or repo info | NEEDS INTERNET (works on your host) |
| `.npm` | Show an npm package info | NEEDS INTERNET (works on your host) |
| `.wiki` | Short Wikipedia summary | NEEDS INTERNET (works on your host) |

## TEXT TOOLS (30)

| Command | What it does | Test status |
|---|---|---|
| `.base64decode` | Decode Base64 text | WORKS |
| `.base64encode` | Encode text to Base64 | WORKS |
| `.binary` | Text to binary | WORKS |
| `.bold` | Bold Unicode text | WORKS |
| `.clap` | Put clap emoji between words | WORKS |
| `.count` | Count characters | WORKS |
| `.flip` | Flip text upside down | WORKS |
| `.frombinary` | Binary to text | WORKS |
| `.fromhex` | Hex to text | WORKS |
| `.frommorse` | Morse code to text | WORKS |
| `.italic` | Italic Unicode text | WORKS |
| `.leet` | Leet-speak text | WORKS |
| `.lower` | Lowercase | WORKS |
| `.mock` | AlTeRnAtInG mock text | WORKS |
| `.morse` | Text to Morse code | WORKS |
| `.palindrome` | Check if a word is a palindrome | WORKS |
| `.repeat` | Repeat text (usage: .repeat 3 ab) | WORKS |
| `.reverse` | Reverse text | WORKS |
| `.reversewords` | Reverse the word order | WORKS |
| `.rot13` | ROT13 cipher | WORKS |
| `.shuffle` | Shuffle letters | WORKS |
| `.smallcaps` | Small capitals text | WORKS |
| `.strike` | Strikethrough text | WORKS |
| `.title` | Title case | WORKS |
| `.tohex` | Text to hex | WORKS |
| `.upper` | Uppercase | WORKS |
| `.vaporwave` | Vaporwave spaced text | WORKS |
| `.vowels` | Count vowels | WORKS |
| `.wordcount` | Count words | WORKS |
| `.zalgo` | Glitchy zalgo text | WORKS |

## TOOLS (4)

| Command | What it does | Test status |
|---|---|---|
| `.average` | Average of numbers (usage: .average 1 2 3) | WORKS |
| `.calc` | Calculator (usage: .calc 2*(3+4)) | WORKS |
| `.password` | Random strong password (usage: .password 16) | WORKS |
| `.percent` | Percentage (usage: .percent 1 4) | WORKS |

## UTILITY (5)

| Command | What it does | Test status |
|---|---|---|
| `.checknumber` | Check if a number is on WhatsApp | WORKS |
| `.qr` | Make a QR code from text | WORKS |
| `.shorten` | Shorten a link | NEEDS INTERNET (works on your host) |
| `.ssweb` | Screenshot of a website | WORKS |
| `.tts` | Text to voice (usage: .tts en hello) | NEEDS INTERNET (works on your host) |

> `.restart` is not run in the automatic tests because it restarts the session. Check it yourself once. Total: 157 commands (156 tested + restart).
