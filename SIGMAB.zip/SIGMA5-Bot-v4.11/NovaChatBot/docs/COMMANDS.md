# SIGMA 5 — Command list

Total WhatsApp commands: 157. Prefix is `.` by default (change with `.setprefix`).

## Group setup (run inside the WhatsApp group, admins only)

| What you want | Type this in the group |
|---|---|
| Welcome card on | `.welcome on` |
| Goodbye card on | `.goodbye on` |
| Bengali text (permanent) | `.lang bn` |
| English text (permanent) | `.lang en` |
| Auto emoji on every member chat | `.autoreact on` |
| Stop auto emoji | `.autoreact off` |
| Remove link senders | `.antilink on` |
| Warn 3 times, then remove | `.antilink warn` |
| Remove on any link | `.antilink all` |
| Turn antilink off | `.antilink off` |

Owner-only (in your own chat): `.statusreact on|off` reacts to contacts' statuses with an emoji; `.autostatus on|off` auto-views them.

Language is set once per group; every member added afterwards gets that language. Cards show the member's own profile picture, number and name.

## All commands by category

### AI (2)

`.ai`, `.groq`

### ANIME (13)

`.anime`, `.character`, `.cry`, `.dance`, `.hug`, `.manga`, `.megumin`, `.neko`, `.pat`, `.shinobu`, `.smile`, `.waifu`, `.wave`

### CONVERTER (10)

`.c2f`, `.cm2in`, `.currency`, `.f2c`, `.in2cm`, `.kg2lb`, `.km2mi`, `.lb2kg`, `.mi2km`, `.toimg`

### DEVOTION (3)

`.bible`, `.gita`, `.quran`

### FUN (11)

`.8ball`, `.compliment`, `.dare`, `.fact`, `.joke`, `.motivate`, `.quote`, `.riddle`, `.trivia`, `.truth`, `.wyr`

### GAMES (8)

`.choose`, `.coinflip`, `.dice`, `.guess`, `.number`, `.rps`, `.ship`, `.slots`

### GENERAL (8)

`.alive`, `.botid`, `.info`, `.menu`, `.owner`, `.ping`, `.runtime`, `.time`

### GROUP (27)

`.add`, `.admin`, `.approve`, `.autoreact`, `.close`, `.demote`, `.desc`, `.goodbye`, `.groupinfo`, `.grouplink`, `.hidetag`, `.invite`, `.kick`, `.lang`, `.leave`, `.lock`, `.open`, `.poll`, `.promote`, `.reject`, `.requests`, `.resetlink`, `.setgpp`, `.subject`, `.tagall`, `.unlock`, `.welcome`

### INFO (5)

`.checkid`, `.getpp`, `.jid`, `.lyrics`, `.weather`

### MEDIA (2)

`.save`, `.sticker`

### MICS (1)

`.trt`

### OWNER (20)

`.anticall`, `.autoread`, `.autorecord`, `.autostatus`, `.autotyping`, `.block`, `.blocklist`, `.broadcast`, `.delete`, `.join`, `.listgc`, `.mode`, `.removepp`, `.restart`, `.setbio`, `.setname`, `.setpp`, `.setprefix`, `.statusreact`, `.unblock`

### PROTECTION (4)

`.antilink`, `.antispam`, `.resetwarn`, `.warnings`

### SEARCH (4)

`.define`, `.github`, `.npm`, `.wiki`

### TEXT TOOLS (30)

`.base64decode`, `.base64encode`, `.binary`, `.bold`, `.clap`, `.count`, `.flip`, `.frombinary`, `.fromhex`, `.frommorse`, `.italic`, `.leet`, `.lower`, `.mock`, `.morse`, `.palindrome`, `.repeat`, `.reverse`, `.reversewords`, `.rot13`, `.shuffle`, `.smallcaps`, `.strike`, `.title`, `.tohex`, `.upper`, `.vaporwave`, `.vowels`, `.wordcount`, `.zalgo`

### TOOLS (4)

`.average`, `.calc`, `.password`, `.percent`

### UTILITY (5)

`.checknumber`, `.qr`, `.shorten`, `.ssweb`, `.tts`

