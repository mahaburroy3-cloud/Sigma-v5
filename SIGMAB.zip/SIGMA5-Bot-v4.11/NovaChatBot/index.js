/**
 * SIGMA 5 — entry point.
 *  - With BOT_TOKEN: starts the Telegram panel (link devices via pairing code) and restores saved WhatsApp sessions.
 *  - Without BOT_TOKEN but with WA_PHONE_NUMBER: pairs that one number from the terminal.
 */
const config = require("./config");
const wa = require("./lib/wa");
const store = require("./lib/store");
const fs = require("fs");
const path = require("path");

fs.mkdirSync(config.sessionsDir, { recursive: true });
process.on("unhandledRejection", (e) => console.error("unhandled:", e?.message || e));
process.on("SIGINT", () => { store.flush(); process.exit(0); });

console.log(`SIGMA 5 v4.0 | Node ${process.version} | folder: ${__dirname}`);
async function checkWhatsAppReachable() {
    try { await fetch("https://web.whatsapp.com", { signal: AbortSignal.timeout(10000) }); console.log("✅ WhatsApp servers are reachable from this server"); }
    catch (e) { console.error(`❌ This server cannot reach WhatsApp (${e.message}). Linking will fail on this host — try another hosting panel.`); }
}
(async () => {
    checkWhatsAppReachable();
    if (config.tgToken) {
        console.log(`Token found in: ${config.tokenSource} (ends with ...${config.tgToken.slice(-4)}). Connecting to Telegram...`);
        require("./lib/telegram").start();
        await wa.restoreAll();
        return;
    }
    if (config.terminalNumber) {
        const n = config.terminalNumber;
        const linked = fs.existsSync(path.join(config.sessionsDir, n, "creds.json"));
        if (linked) { await wa.startSession(n); console.log("Resuming WhatsApp session for +" + n); return; }
        const code = await wa.startSession(n, { wantCode: true });
        console.log(`\nPairing code for +${n}:  ${code}\nWhatsApp > Linked devices > Link a device > Link with phone number instead\n`);
        wa.events.on("connected", () => console.log("✅ Connected. Send .menu on WhatsApp."));
        return;
    }
    console.error(
        "\n❌ BOT_TOKEN not set.\n" +
        "   1. Open the file  settings.json  (same folder as index.js)\n" +
        "   2. Put your BotFather token between the quotes after \"BOT_TOKEN\":\n" +
        "   3. Save, then restart the server.\n" +
        "   (Looking in: " + __dirname + ")\n");
    setInterval(() => {}, 1 << 30); // stay alive so this message stays on screen instead of crash-looping
})();
